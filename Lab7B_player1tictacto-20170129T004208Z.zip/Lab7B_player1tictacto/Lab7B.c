//*****************************************************************************
// TITLE: TIC TAC TOE PLAYER 1
//
// NAME: Arup Arcalgud, Aaron Wright, Becca E
// LAB SECTION: <301>
// LAB DAY: <Tues>
//
// CLASS: ECE 210
// DATE: FALL 2014
//
// DESCRIPTION: <plays tic tac toe on two boards>
//*****************************************************************************


#define BUFF_LEN 22
#include <stdio.h>


// Initialization Functions
void LEDBARInit(void);
void DIPSWInit(void);
void PBSwInit(void);
void RGB_LEDInit(void);
void sysTickInit(void);
// Inputs, outputs, and wait timers
int read_PBSwitchNum(int SwitchNumber);
int read_Switches(void);
void LEDBAROutput(int value);



void sysTickWait1mS(int waitTime);
void 	Xbee_ConfigureAddresses(int destAddress, int ownAddress);
void 	Xbee_Send(int message);
int		Xbee_Receive(void);
void Xbee_SendArray(char *s, int messageLength);
int  Xbee_ReceiveArray(char* message, int messageLength);



void turnOn(char color);
void turnOff(char color);


void potentiometersInit(void);
int readPotentiometer0(void);
int potenValue0;



void sysTickWait1mS(int waitTime);
void RIT128x96x4Init(int freq);
void RIT128x96x4Clear(void);
void RIT128x96x4StringDraw(const char* letter, int xx, int yy, int intensity);
char* convert(int baudotCode);

int ii;   					//for counter variable
int xx;							//x axis string position
int yy;							//y axis string position
int i;
int baudotCodes[10];
int numberOfCodes;
int currentCode;


//void drawBoard(char* boardData);

//image draw:
void    sysTickWait1mS(int waitTime);
void	RIT128x96x4Init(int freq);
void    RIT128x96x4Clear(void); 
void    RIT128x96x4StringDraw(const char* letter, int xx, int yy, int intensity);
char* 	convert(int baudotCode);
void RIT128x96x4ImageDraw(const unsigned char *pucImage, unsigned long ulX,
                     unsigned long ulY, unsigned long ulWidth,
                     unsigned long ulHeight);

//lab5 stuff


int PB1, PB2, PB3;
int status = 0x15;


 //MISC VARIABLES (IE. COUNTERS, FLAGS, ETC.)
 int play = 1;
 
 int a;	//integer used in the switch case for printing X's on THIS board, and to send to print X's on OTHER board
 int b; //integer used in the switch case for printing O's on THIS board, and to send to print O's on OTHER board
 int c; //turn counter
										 
 int SwitchNum; //the number of the switch we wish to read
 int SwitchHit; //is a 1 if the switch is pressed, else 0 
//*****************************************************************************
//
// Main Program:
//
//*****************************************************************************






int
main(void)
{
//Initializing the variables used in the lab.
char rowArray[64];
char colArray[96];
	
	//Initializing the variables used in the lab.
	int baudotCodes[10];
	int numberOfCodes;
	int ii;   					//for counter variable
	int xx;							//x axis string position
	int yy;							//y axis string position
	int currentCode;
	int potenValue0;
	int potenValue1;
	int potenValue2;
	int i;
	int a = 0;
	int count;
	int recStatus;
	int winner = 0;
	int gameOver = 0;
	
	char playerO[] = "Player O Wins";
	char playerX[] = "Player X Wins";
	
	char boxStatus[9] = {0,0,0,0,0,0,0,0,0};
	char xPosition[9] = {18, 60, 102, 18, 60, 102, 18, 60, 102};
	char yPosition[9] = {12, 12, 12, 44, 44, 44, 76, 76, 76};
	
	char msgSend[3] = {0, 0, 0};
	char msgRec[3];
	
	int destAddress = 2;
	int ownAddress = 1;
								
	//Initializing the LEDBAR, RGB LED, DIPSwitches and Pushbuttons, and a wait timer
	LEDBARInit();
	DIPSWInit();
	PBSwInit();
	RGB_LEDInit();
	sysTickInit();
	potentiometersInit();
	RIT128x96x4Init(1000000);
	
	c = 0;	


 
//CODE FOR DRAWING BOARD <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
  //Clear messages on the screen
	RIT128x96x4Clear();
	
	//Start at the upper left hand corner of the screen!
	xx = 0;
	yy = 0;
	
	//Time to set the Xbee up.
	Xbee_ConfigureAddresses(destAddress, ownAddress);

	
	RIT128x96x4Clear();
	
	for (i=0; i < 64; i++)
	{
		rowArray[i] = 0xFF;
	}
	
	for (i=0; i < 96; i++)
	{
		colArray[i] = 0xF0;
	}
	
		
	RIT128x96x4ImageDraw(rowArray, 0 /*ulX*/,
									 31 /*ulY*/, 128 /*ulWidth*/,
									 1 /*ulHeight*/);

	RIT128x96x4ImageDraw(rowArray, 0 /*ulX*/,
									 63 /*ulY*/, 128 /*ulWidth*/,
									 1 /*ulHeight*/);

	RIT128x96x4ImageDraw(colArray, 42 /*ulX*/,
									 0 /*ulY*/, 2 /*ulWidth*/,
									 96 /*ulHeight*/);

	RIT128x96x4ImageDraw(colArray, 84 /*ulX*/,
									 0 /*ulY*/, 2 /*ulWidth*/,
									 96 /*ulHeight*/);
	
	PB1 = read_PBSwitchNum(1);
	while(PB1 == 1)
	{
		potenValue0 = readPotentiometer0();

		if((potenValue0 > 0) && (potenValue0 <= 113))
		{
			a = 1;
		}  
		if((potenValue0 > 113) && (potenValue0 <= 226))
		{
			a = 2;
		}
		if((potenValue0 > 226) && (potenValue0 <= 339))
		{
			a = 3;
		}
		if((potenValue0 > 339) && (potenValue0 <= 452))
		{
			a = 4;
		}
		if((potenValue0 > 452) && (potenValue0 <= 565))
		{
			a = 5;
		}
		if((potenValue0 > 565) && (potenValue0 <= 678))
		{
			a = 6;
		}
		if((potenValue0 > 678) && (potenValue0 <= 791))
		{
			a = 7;
		}
		if((potenValue0 > 791) && (potenValue0 <= 904))
		{
			a = 8;
		}
		if((potenValue0 > 904) && (potenValue0 <= 1024))
		{
			a = 9;
		}
		
		for(count = 0; count < 9; count++)
		{
			if (boxStatus[count] == 0)
			{
				RIT128x96x4StringDraw(" ", xPosition[count], yPosition[count],15);
			}
			
		}
		
		switch(a)
		{
			case(1):
				RIT128x96x4StringDraw("X", 18,12,15);
			
				break;
			case(2):
				RIT128x96x4StringDraw("X",60,12,15);
				break;
			case(3):
				RIT128x96x4StringDraw("X",102,12,15);
				break;
			case(4):
				RIT128x96x4StringDraw("X",18,44,15);
				break;
			case(5):
				RIT128x96x4StringDraw("X",60,44,15);
				break;
			case(6):
				RIT128x96x4StringDraw("X",102,44,15);
				break;
			case(7):
				RIT128x96x4StringDraw("X",18,76,15);
				break;
			case(8):
				RIT128x96x4StringDraw("X",60,76,15);
				break;
			case(9):	
				RIT128x96x4StringDraw("X",102,76,15);
				break;
		}
		
//		for(count = 0; count < 9; count++)
//		{
//			if (boxStatus[count] == 0)
//			{
//				RIT128x96x4StringDraw(" ", xPosition[count], yPosition[count],15);
//			}
//			
//		}
		
		PB1 = read_PBSwitchNum(1);
	}
	
	boxStatus[a-1] = 1;
	msgSend[0] = 0;
	msgSend[1] = 0;
	msgSend[2] = a;
	Xbee_SendArray(msgSend, 3);

	while(1)
	{
		recStatus =  Xbee_ReceiveArray(msgRec, 3);
		
		while(recStatus == 0x5A5)
		{
			recStatus =  Xbee_ReceiveArray(msgRec, 3);
			turnOn('R');
		}
		turnOff('R');
		
		if(msgRec[0] != 0)
		{
			if(msgRec[1] == 1)
			{RIT128x96x4Clear();
				RIT128x96x4StringDraw(playerX, 0, 0, 15);
				// Player 1 wins
			}
			
			else if(msgRec[1] == 2)
			{RIT128x96x4Clear();
			 RIT128x96x4StringDraw(playerO, 0, 0, 15);
				// Player 2 wins
			}
		}
		
		else
		{
			boxStatus[msgRec[2] - 1] = 2;
			
		}
		
		if((boxStatus[0] == boxStatus[3]) && (boxStatus[0] == boxStatus[6]) && (boxStatus[3] == boxStatus[6]))
		{
			if(boxStatus[0] == 1)
			{
				winner = 1;
				gameOver = 1;
			}
			
			else if (boxStatus[0] == 2)
			{
				winner = 2;
				gameOver = 1;
			}
			
			else
				winner = 0;
		}
		
		else if((boxStatus[1] == boxStatus[4]) && (boxStatus[1] == boxStatus[7]) && (boxStatus[4] == boxStatus[7]))
		{
			if(boxStatus[1] == 1)
			{
				winner = 1;
				gameOver = 1;
			}
			
			else if (boxStatus[1] == 2)
			{
				winner = 2;
				gameOver = 1;
			}
			
			else
				winner = 0;
		}
		
		else if((boxStatus[2] == boxStatus[5]) && (boxStatus[2] == boxStatus[8]) && (boxStatus[5] == boxStatus[8]))
		{
			if(boxStatus[2] == 1)
			{
				winner = 1;
				gameOver = 1;
			}
			
			else if (boxStatus[2] == 2)
			{
				winner = 2;
				gameOver = 1;
			}
			
			else
				winner = 0;
		}
		
		else if((boxStatus[0] == boxStatus[4]) && (boxStatus[0] == boxStatus[8]) && (boxStatus[4] == boxStatus[8]))
		{
			if(boxStatus[0] == 1)
			{
				winner = 1;
				gameOver = 1;
			}
			
			else if (boxStatus[0] == 2)
			{
				winner = 2;
				gameOver = 1;
			}
			
			else
				winner = 0;
		}
		
		else if((boxStatus[2] == boxStatus[4]) && (boxStatus[2] == boxStatus[6]) && (boxStatus[4] == boxStatus[6]))
		{
			if(boxStatus[2] == 1)
			{
				winner = 1;
				gameOver = 1;
			}
			
			else if (boxStatus[2] == 2)
			{
				winner = 2;
				gameOver = 1;
			}
			
			else
				winner = 0;
		}
		
		else if((boxStatus[0] == boxStatus[1]) && (boxStatus[0] == boxStatus[2]) && (boxStatus[1] == boxStatus[2]))
		{
			if(boxStatus[0] == 1)
			{
				winner = 1;
				gameOver = 1;
			}
			
			else if (boxStatus[0] == 2)
			{
				winner = 2;
				gameOver = 1;
			}
			
			else
				winner = 0;
		}
		
		else if((boxStatus[3] == boxStatus[4]) && (boxStatus[3] == boxStatus[5]) && (boxStatus[4] == boxStatus[5]))
		{
			if(boxStatus[3] == 2)
			{
				winner = 2;
				gameOver = 1;
			}
			
			else if (boxStatus[3] == 1)
			{
				winner = 1;
				gameOver = 1;
			}
			
			else
				winner = 0;
		}
		
		else if((boxStatus[6] == boxStatus[7]) && (boxStatus[6] == boxStatus[8]) && (boxStatus[7] == boxStatus[8]))
		{
			if(boxStatus[6] == 2)
			{
				winner = 2;
				gameOver = 1;
			}
			
			else if (boxStatus[6] == 1)
			{
				winner = 1;
				gameOver = 1;
			}
			
			else
				winner = 0;
		}
		
		else if ((boxStatus[0] != 0) && (boxStatus[1] != 0) && (boxStatus[2] != 0) && (boxStatus[3] != 0) && (boxStatus[4] != 0) && (boxStatus[5] != 0) && (boxStatus[6] != 0) && (boxStatus[7] != 0) && (boxStatus[8] != 0) )
		{
			gameOver = 1;
		}
		
		if(gameOver == 1)
		{
			// Clear Board, announce the winner
			if(winner == 1)
			{
				RIT128x96x4Clear();
				RIT128x96x4StringDraw(playerX, 0, 0, 15);
				// Player 1 wins
			}
			
			else if(winner == 2)
			{
				RIT128x96x4Clear();
				RIT128x96x4StringDraw(playerO, 0, 0, 15);
				// Player 2 wins
			}
		}
		
		else
		{
			PB1 = read_PBSwitchNum(1);
	while(PB1 == 1)
	{
		potenValue0 = readPotentiometer0();

		if((potenValue0 > 0) && (potenValue0 <= 113))
		{
			a = 1;
		}  
		if((potenValue0 > 113) && (potenValue0 <= 226))
		{
			a = 2;
		}
		if((potenValue0 > 226) && (potenValue0 <= 339))
		{
			a = 3;
		}
		if((potenValue0 > 339) && (potenValue0 <= 452))
		{
			a = 4;
		}
		if((potenValue0 > 452) && (potenValue0 <= 565))
		{
			a = 5;
		}
		if((potenValue0 > 565) && (potenValue0 <= 678))
		{
			a = 6;
		}
		if((potenValue0 > 678) && (potenValue0 <= 791))
		{
			a = 7;
		}
		if((potenValue0 > 791) && (potenValue0 <= 904))
		{
			a = 8;
		}
		if((potenValue0 > 904) && (potenValue0 <= 1024))
		{
			a = 9;
		}
		
		for(count = 0; count < 9; count++)
		{
			if (boxStatus[count] == 0)
			{
				RIT128x96x4StringDraw(" ", xPosition[count], yPosition[count],15);
			}
			else if (boxStatus[count] == 1)
			{
				RIT128x96x4StringDraw("X", xPosition[count], yPosition[count],15);
			}
			else if (boxStatus[count] == 2)
			{
				RIT128x96x4StringDraw("O", xPosition[count], yPosition[count],15);
			}
			
		}
		
		switch(a)
		{
			case(1):
				RIT128x96x4StringDraw("X", 18,12,15);
			
				break;
			case(2):
				RIT128x96x4StringDraw("X",60,12,15);
				break;
			case(3):
				RIT128x96x4StringDraw("X",102,12,15);
				break;
			case(4):
				RIT128x96x4StringDraw("X",18,44,15);
				break;
			case(5):
				RIT128x96x4StringDraw("X",60,44,15);
				break;
			case(6):
				RIT128x96x4StringDraw("X",102,44,15);
				break;
			case(7):
				RIT128x96x4StringDraw("X",18,76,15);
				break;
			case(8):
				RIT128x96x4StringDraw("X",60,76,15);
				break;
			case(9):	
				RIT128x96x4StringDraw("X",102,76,15);
				break;
		}
		
//		for(count = 0; count < 9; count++)
//		{
//			if (boxStatus[count] == 0)
//			{
//				RIT128x96x4StringDraw(" ", xPosition[count], yPosition[count],15);
//			}
//			
//		}
		
		PB1 = read_PBSwitchNum(1);
	}
	
	boxStatus[a-1] = 1;
	msgSend[0] = gameOver;
	msgSend[1] = winner;
	msgSend[2] = a;
	Xbee_SendArray(msgSend, 3);
			
		}
		
			
		
		
		
// while(play == 1){
	 			
//FILL BOARD WITH 



//FUNCTION TO SEND X'S FROM THIS BOARD<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


//CHECKWIN AT START OF each X SELECTION LOOP<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

/*
if ("X",3,3,15) && ("X",3,9,15) && ("X",3,16,15)            //theres gonna be 17 of these
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player X wins", 0, 0, 15);
				}
if ("X",7,3,15) && ("X",7,9,15) && ("X",7,16,15)            //horizontal 3 combinations
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player X wins", 0, 0, 15);
				}	
if ("X",11,3,15) && ("X",11,9,15) && ("X",11,16,15)
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player X wins", 0, 0, 15);
				}

if ("X",3,3,15) && ("X",7,3,15) && ("X",11,3,15)            //vertical 3 combinations
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player X wins", 0, 0, 15);
				}
if ("X",3,9,15) && ("X",7,9,15) && ("X",11,9,15)
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player X wins", 0, 0, 15);
				}
if ("X",3,16,15) && ("X",7,16,15) && ("X",11,16,15)
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player X wins", 0, 0, 15);
				}				

if ("X",3,3,15) && ("X",7,9,15) && ("X",11,16,15)                 //diagonal?    ?    ?
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player X wins", 0, 0, 15);
				}				
if ("X",3,16,15), ("X",7,9,15), ("X",11,3,15)                 //diagonal?    ?    ?
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player X wins", 0, 0, 15);
				}

				
				
				
				
				
if ("O",3,3,15) && ("O",3,9,15) && ("O",3,16,15)          
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player O wins", 0, 0, 15);
				}
if ("O",7,3,15) && ("O",7,9,15) && ("O",7,16,15)            //horizontal 3 combinations
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player O wins", 0, 0, 15);
				}	
if ("O",11,3,15) && ("O",11,9,15) && ("O",11,16,15)
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player O wins", 0, 0, 15);
				}

if ("O",3,3,15) && ("O",7,3,15) && ("O",11,3,15)            //vertical 3 combinations
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player O wins", 0, 0, 15);
				}
if ("O",3,9,15) && ("O",7,9,15) && ("O",11,9,15)
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player O wins", 0, 0, 15);
				}
if ("O",3,16,15) && ("O",7,16,15) && ("O",11,16,15)
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player O wins", 0, 0, 15);
				}				

if ("O",3,3,15) && ("O",7,9,15) && ("O",11,16,15)                 //diagonal?    ?    ?
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player O wins", 0, 0, 15);
				}				
if ("O",3,16,15) && ("O",7,9,15) && ("O",11,3,15)                 //diagonal?    ?    ?
				{RIT128x96x4Clear(); //reset
				RIT128x96x4StringDraw("Player O wins", 0, 0, 15);
				}

*/				
//if (c == 9)
//		{RIT128x96x4Clear(); //reset
//		RIT128x96x4StringDraw("NOBODY WON, MAYBE ITS A STALEMATE, I DONT REALLY KNOW, WHATEVER MAN", 0, 0, 15);
//		}																													//17th condition, if board is full of win
////END OF CHECKWIN, BEGINNING OF X SELECTION, ALL OF THIS IS A LOOP I HOPE BECAUSE IT SHOULD BE
//				
//potenValue0 = readPotentiometer0();

//if((potenValue0 > 0) && (potenValue0 <= 113))
//{
//	int a = 1;
//}  
//if((potenValue0 > 113) && (potenValue0 <= 113))
//{
//	int a = 2;
//}
//if((potenValue0 > 113) && (potenValue0 <= 226))
//{
//	int a = 3;
//}
//if((potenValue0 > 226) && (potenValue0 <= 339))
//{
//	int a = 4;
//}
//if((potenValue0 > 339) && (potenValue0 <= 452))
//{
//	int a = 5;
//}
//if((potenValue0 > 452) && (potenValue0 <= 565))
//{
//	int a = 6;
//}
//if((potenValue0 > 565) && (potenValue0 <= 678))
//{
//	int a = 7;
//}
//if((potenValue0 > 678) && (potenValue0 <= 791))
//{
//	int a = 8;
//}
//if((potenValue0 > 791) && (potenValue0 <= 1024))
//{
//	int a = 9;
//}

//	//hit pb3 to select and send
//SwitchNum = 3;
//SwitchHit = read_PBSwitchNum(SwitchNum);

//if(SwitchHit == 1)
//{
//	Xbee_Send(a);
//	c = c + 1;
//	
//}

//	//switch case 
//switch(a)
//{
//case(1):
//	RIT128x96x4StringDraw("X",3,3,15);
//case(2):
//	RIT128x96x4StringDraw("X",3,9,15);
//case(3):
//	RIT128x96x4StringDraw("X",3,16,15);
//case(4):
//	RIT128x96x4StringDraw("X",7,3,15);
//case(5):
//	RIT128x96x4StringDraw("X",7,9,15);
//case(6):
//	RIT128x96x4StringDraw("X",7,16,15);
//case(7):
//	RIT128x96x4StringDraw("X",11,3,15);
//case(8):
//	RIT128x96x4StringDraw("X",11,9,15);
//case(9):	
//	RIT128x96x4StringDraw("X",11,16,15);
//}
//	


////FUNCTION TO RECEIVE O'S FROM OTHER BOARD<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//b = Xbee_Receive();


//switch(b)
//{
//case(1):
//	RIT128x96x4StringDraw("O",3,3,15);
//case(2):
//	RIT128x96x4StringDraw("O",3,9,15);
//case(3):
//	RIT128x96x4StringDraw("O",3,16,15);
//case(4):
//	RIT128x96x4StringDraw("O",7,3,15);
//case(5):
//	RIT128x96x4StringDraw("O",7,9,15);
//case(6):
//	RIT128x96x4StringDraw("O",7,16,15);
//case(7):
//	RIT128x96x4StringDraw("O",11,3,15);
//case(8):
//	RIT128x96x4StringDraw("O",11,9,15);
//case(9):	
//	RIT128x96x4StringDraw("O",11,16,15);
//}
//c = c + 1;
}

 
}

/* The convert() function maps 5 bit Baudot codes to the output needed for 
   for the LCD Display */


 
